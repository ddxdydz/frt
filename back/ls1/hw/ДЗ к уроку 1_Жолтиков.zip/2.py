number = int(input("Введите число: "))
is_even = number % 2 == 0
print(is_even)
