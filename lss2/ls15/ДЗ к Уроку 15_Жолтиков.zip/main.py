from flask import Flask, request, jsonify

app = Flask(__name__)

users = [
    {"id": 1, "fio": "Иванов", "age": 25},
    {"id": 2, "fio": "Петров", "age": 28},
    {"id": 3, "fio": "Сидоров", "age": 21},
]


def get_next_id():
    if users:
        return max(users, key=lambda user: user["id"])["id"] + 1
    return 1


@app.route('/users', methods=['GET'])
def get_users():
    return jsonify(users)


@app.route('/users/<int:user_id>', methods=['GET'])
def get_user(user_id):
    for user in users:
        if user['id'] == user_id:
            return jsonify(user)
    return jsonify({"error": "User not found"}), 404


@app.route('/users', methods=['POST'])
def add_user():
    data = request.get_json()
    if not data or 'fio' not in data or 'age' not in data:
        return jsonify({"error": "Bad request"}), 400
    new_user = {"id": get_next_id(), "fio": data['fio'], "age": data['age']}
    users.append(new_user)
    return jsonify(new_user), 201


@app.route('/users/<int:user_id>', methods=['PUT'])
def update_user(user_id):
    for i, user in enumerate(users):
        if user['id'] == user_id:
            data = request.get_json()
            if not data:
                return jsonify({"error": "Request body is empty"}), 400
            if 'fio' in data:
                users[i]['fio'] = data['fio']
            if 'age' in data:
                users[i]['age'] = data['age']
            return jsonify(users[i])
    return jsonify({"error": "User not found"}), 404


@app.route('/users/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    for i, user in enumerate(users):
        if user['id'] == user_id:
            del users[i]
            return jsonify({"message": "User deleted"})
    return jsonify({"error": "User not found"}), 404


if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=8082)
