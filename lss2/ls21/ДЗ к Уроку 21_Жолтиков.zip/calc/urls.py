from django.urls import path
from .views import index, calculate

urlpatterns = [
    path('', index, name='index'),
    path('calculate/', calculate, name='calculate'),
]
