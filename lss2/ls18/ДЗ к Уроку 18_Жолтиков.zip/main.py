from flask import Flask, request, jsonify

app = Flask(__name__)

products = [
    {"id": 1, "name": "Product A", "description": "Product A description", "price": 10.00},
    {"id": 2, "name": "Product B", "description": "Product B description", "price": 25.50},
    {"id": 3, "name": "Product C", "description": "Product C description", "price": 5.00},
]


def get_next_product_id():
    if products:
        return max(products, key=lambda product: product["id"])["id"] + 1
    return 1


@app.route('/products', methods=['GET'])
def get_products():
    return jsonify(products)


@app.route('/products/<int:product_id>', methods=['GET'])
def get_product(product_id):
    for product in products:
        if product['id'] == product_id:
            return jsonify(product)
    return jsonify({"error": "Product not found"}), 404


@app.route('/products', methods=['POST'])
def add_product():
    data = request.get_json()
    if not data or 'name' not in data or 'price' not in data or 'description' not in data:
        return jsonify({"error": "Bad request"}), 400

    new_product = {
        "id": get_next_product_id(),
        "name": data['name'],
        "description": data['description'],
        "price": data['price']
    }
    products.append(new_product)
    return jsonify(new_product), 201


@app.route('/products/<int:product_id>', methods=['PUT'])
def update_product(product_id):
    for i, product in enumerate(products):
        if product['id'] == product_id:
            data = request.get_json()
            if not data:
                return jsonify({"error": "Request body is empty"}), 400

            for key, value in data.items():
                if key in ["name", "description", "price"]:
                    products[i][key] = value

            return jsonify(products[i])
    return jsonify({"error": "Product not found"}), 404


@app.route('/products/<int:product_id>', methods=['DELETE'])
def delete_product(product_id):
    for i, product in enumerate(products):
        if product['id'] == product_id:
            del products[i]
            return jsonify({"message": "Product deleted"}), 200
    return jsonify({"error": "Product not found"}), 404


if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=8082)
