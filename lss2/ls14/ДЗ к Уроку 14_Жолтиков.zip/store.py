from flask import Flask,render_template,request
import psycopg2

from psycopg2.extras import RealDictCursor


app = Flask(__name__)

connect = psycopg2.connect(
    host="localhost",
    user="postgres",
    password="postgres",
    dbname="lesson10",
    port="5432"
)


def get_item_by_id(id):
    sql = f"SELECT * FROM cars WHERE id = {id}"
    cursor.execute(sql)
    return cursor.fetchone()


with connect:
   cursor = connect.cursor(cursor_factory=RealDictCursor)


@app.route('/')
def catalog():
    sql = "SELECT * FROM cars"
    cursor.execute(sql)
    data = cursor.fetchall()
    return render_template('catalog.html',items=data)


@app.route('/card_item')
def card_item():
    id = request.args['id']
    if id.isdigit():
        id = int(id)
        sql = f"SELECT * FROM cars WHERE id={id}"
        cursor.execute(sql)
        data = cursor.fetchone()
        return render_template('card_item.html',item=data)
    return "Error!"


@app.route('/add_cart')
def add_cart():
    id = request.args['id']
    if id.isdigit():
        id = int(id)
        #Ищем товар в корзине, т.е. вдруг он уже там есть
        sql = f"SELECT id FROM cart WHERE item_id={id}"
        cursor.execute(sql)
        count = cursor.fetchone()
        #Если добавляемый товар уже сущесвует в корзине
        if count:
            sql_update = f"UPDATE cart SET count=count+1 WHERE item_id={id}"
            cursor.execute(sql_update)
        else:
            sql_insert = f"INSERT INTO cart(item_id,count) VALUES ({id},1)"
            cursor.execute(sql_insert)
        connect.commit()
        return "Товар успешно добавлен в корзину!"
    return "Ошибка!"


# Вывести корзину покупок

@app.route('/cart')
def cart():
    total_price = 0
    sql = f"SELECT item_id,count FROM cart WHERE"
    cursor.execute(sql)
    items = cursor.fetchall()
    for item in items:
        #Получим всю информацию о товаре из каталога
        data = get_item_by_id(item['item_id'])
        item['title'] = data['title']
        item['price'] = data['price']
        item['photo'] = data['photo']
        total_price += int(data['price']) * int(item["count"])

    return render_template('cart.html', items=items, total_price=total_price)


app.run(debug=True,host='127.0.0.1',port=8082)