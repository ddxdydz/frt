CREATE TABLE cars(
   id serial primary key,
   title varchar(30),
   price numeric,
   photo varchar(50)
);
INSERT INTO cars(title,price,photo) VALUES('Audi',1000,'audi.jpg'),('BMW',1200,'bmw.jpg'),('Skoda',900,'skoda.jpg'),('VW',890,'vw.jpg');

CREATE TABLE cart(
    id serial,
    item_id integer,
    count integer
);
