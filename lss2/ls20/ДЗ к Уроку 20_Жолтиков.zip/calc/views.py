from django.shortcuts import render
from django.http import JsonResponse
from .operations import add, subtract, multiply, divide


def index(request):
    return render(request, 'index.html')


def calculate(request):
    if request.method == "POST":
        num1 = float(request.POST.get('num1'))
        num2 = float(request.POST.get('num2'))
        operation = request.POST.get('operation')

        if operation == 'add':
            result = add(num1, num2)
        elif operation == 'subtract':
            result = subtract(num1, num2)
        elif operation == 'multiply':
            result = multiply(num1, num2)
        elif operation == 'divide':
            result = divide(num1, num2)
        else:
            result = "Invalid operation"

        return JsonResponse({'result': result})
