text = "Silence is golden"
for word in text.split():
    print(word)
    