sports = ["Футбол", "Баскетбол"]

favorite_sport = input("Введите ваш любимый вид спорта: ")
sports.append(favorite_sport)

sports.sort()

print("Отсортированный список видов спорта:", sports)
